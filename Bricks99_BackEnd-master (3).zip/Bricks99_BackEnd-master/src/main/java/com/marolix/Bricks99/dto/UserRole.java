package com.marolix.Bricks99.dto;

public enum UserRole {
	ADMIN, BUYER, SELLER
}
