package com.marolix;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Check2ApplicationTests {



}
